<?php
require_once("template-blog.php");
?>
