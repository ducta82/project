<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-bottom') ):
//here default sidebar content
endif;
?>