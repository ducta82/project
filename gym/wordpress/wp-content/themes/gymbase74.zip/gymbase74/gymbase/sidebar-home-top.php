<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('home-top') ):
//here default sidebar content
endif;
?>