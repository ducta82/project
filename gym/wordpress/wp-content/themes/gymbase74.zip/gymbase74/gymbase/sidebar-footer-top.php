<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-top') ):
//here default sidebar content
endif;
?>