<?php
if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('home-right') ):
//here default sidebar content
endif;
?>